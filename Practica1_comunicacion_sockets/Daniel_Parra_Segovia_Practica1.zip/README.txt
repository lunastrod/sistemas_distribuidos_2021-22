uso un makefile

"make all" en cada directorio compila los 2 ficheros de cada directorio
